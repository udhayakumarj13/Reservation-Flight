package com.ticket.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ticket.feign.FlightServicefeignClient;
import com.ticket.feign.TravelerServiceFeignClient;
import com.ticket.model.Flight;
import com.ticket.model.Ticket;
import com.ticket.model.Traveler;
import com.ticket.repository.TicketRepository;

@Service
public class TicketService {
	@Autowired
	TicketRepository ticketrepository;
	@Autowired
	FlightServicefeignClient feignclient;
	@Autowired
	TravelerServiceFeignClient travelerfeignclient;
	
	public String bookTicket(Ticket ticket) {
		Flight flight = feignclient.getFlightById(ticket.getFlightId());
		Traveler traveler = travelerfeignclient.getTravelerById(ticket.getpId());
		Optional<Traveler> optional = Optional.ofNullable(traveler);
		if (optional.isPresent()) {
			if (flight.getAvailableSeats() >= ticket.getBookSeats()) {
				int randomNum = ((int) (Math.random() * 100));
				int availableSeat = flight.getAvailableSeats() - ticket.getBookSeats();
				System.out.println("Available Seats are:" + availableSeat);
				flight.setAvailableSeats(availableSeat);
				ticket.setPname(traveler.getpFirstName());
				ticket.setSeatNumber(randomNum);
				ticket.setBookSeats(ticket.getBookSeats());
				ticket.setDateOfJourney(flight.getDateOfJourney());
				ticket.setSource(flight.getSource());
				ticket.setDestination(flight.getDestination());
				ticket.setFlightId(flight.getFlightId());
				feignclient.updateFlight(flight);
				ticketrepository.save(ticket);
				return "Ticket Booking Successfully";
			} else {

				return "Seats Not Avialable";
			}
		}
		return "Invalid Passenger..";

	}

	public List<Ticket> getAllTickets() {
		return (List<Ticket>) ticketrepository.findAll();
	}

	public Ticket updateTicket(Ticket ticket) {
		Ticket ticket1 = ticketrepository.getById(ticket.getTicketId());
		if (ticket1.getTicketId() == ticket.getTicketId()) {
			ticket1.setTicketId(ticket.getTicketId());
			ticket1.setDestination(ticket.getDestination());
			ticket1.setDateOfJourney(ticket.getDateOfJourney());
		}
		return ticketrepository.save(ticket1);
	}

	public void deleteById(Integer ticketId) {
		Ticket ticket = ticketrepository.getById(ticketId);
		Flight flight = feignclient.getFlightById(ticket.getFlightId());
		flight.setAvailableSeats(flight.getAvailableSeats() + ticket.getBookSeats());
		feignclient.updateFlight(flight);
		ticketrepository.deleteById(ticketId);

	}

	public List<Flight> getAllFlights() {
		
 List<Flight> flightList=feignclient.getAllFlights().stream().filter(x-> x.getAvailableSeats()!=0).collect(Collectors.toList());
		return flightList;
		
	}

	public Flight getFlightById(Integer flightId) {
		return feignclient.getFlightById(flightId);

	}

	public Ticket getTicketById(Integer ticketId) {
		return ticketrepository.findByTicketId(ticketId);

	}

//	@CircuitBreaker(fallbackMethod = "TravelerDetailsFallBack", name = TICKET_SERVICE)
//	public String getuserEmailAndPassword(String emailId, String password) {
//		return travelerfeignClient.getuserEmailAndPassword(emailId, password);
//
//	}

	public Traveler getTravelerById(Integer pId) {
		return travelerfeignclient.getTravelerById(pId);
	}

	String TravelerDetailsFallBack(Exception e) {
		return "user service is down";
	}


}
