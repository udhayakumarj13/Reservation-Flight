package com.ticket.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.ticket.feign.FlightServicefeignClient;
import com.ticket.feign.TravelerServiceFeignClient;
import com.ticket.model.Flight;
import com.ticket.model.Ticket;
import com.ticket.model.Traveler;



@RestController
@RequestMapping(value="ticket")
@CrossOrigin(origins = "http://localhost:4200")
public class Ticketcontroller {
	@Autowired
	com.ticket.service.TicketService ticketservice;
	//@Autowired
	//FlightServicefeignClient  ffeignclients;
	//@Autowired
	//TravelerServiceFeignClient tfeignclient;
	
	
	     //http://localhost:9700/ticket/book
		@PostMapping(value="/book")
	    public String BookTicket(@RequestBody Ticket ticket) {
			return	ticketservice.bookTicket(ticket);
	
		}
		
		//http://localhost:9700/ticket/viewAllTicket
		@GetMapping(value="/viewAllTicket")
		public List<Ticket> getAllTickets() {
			return (List<Ticket>) ticketservice.getAllTickets();
			}
		
		//http://localhost:9700/Ticket/updateTicket
		@PutMapping(value="/updateTicket")
		public Ticket updateTicket(@RequestBody Ticket ticket) {
			return ticketservice.updateTicket(ticket);
			
		}
		// http://localhost:9700/Ticket/getTicketById/14
		@GetMapping(value="/getTicketById/{ticketId}")
		public Ticket getTicketById(@PathVariable Integer ticketId) {
			return ticketservice.getTicketById(ticketId);
			
		} 
			
       //http://localhost:9700/Ticket/getdeleteById
		@DeleteMapping(value="/getdeleteById/{ticketId}")
		public String deleteById(@PathVariable Integer ticketId) {
			ticketservice.deleteById(ticketId);
			return "Deleted...";
		}

		
		 //http://localhost:9700/Ticket/viewAll 
		@GetMapping(value="/viewAll") 
		public List<Flight> getAllFlights(){ 
			return ticketservice.getAllFlights();
		 }
		
		//http://localhost:9700/Ticket/getFlightById/14
		@GetMapping(value="/getFlightById/{flightId}")
		public Flight getFlightById(@PathVariable Integer flightId) {
			return ticketservice.getFlightById(flightId) ;
		 }
		
		
		//http://localhost:9700/Ticket/userLogin?emailId=amy@gmail.com&password=amy@1234$
//	      @GetMapping("/userLogin")
//		 public String getuserEmailAndPassword(@RequestParam String emailId, @RequestParam String password) {
//			return ticketservice.getuserEmailAndPassword(emailId, password);
//		}
	      
	      
	     // http://localhost:9700/Ticket/getTravelerById/2
	      @GetMapping(value="/getTravelerById/{pId}")
	  	public Traveler getTravelerById(@PathVariable Integer pId) {
			return ticketservice.getTravelerById(pId);
	    	  
	      }
	      
	    

}
