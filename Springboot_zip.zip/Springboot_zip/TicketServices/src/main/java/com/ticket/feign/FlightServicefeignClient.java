package com.ticket.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ticket.model.Flight;




@FeignClient(value = "flight-Service", url = "http://localhost:9000/flight")
public interface FlightServicefeignClient {
	
	@GetMapping(value="/getFlightById/{flightId}")
	public Flight getFlightById(@PathVariable Integer flightId);
	

	
	 
	 //http://localhost:8083/flight/update
	 
	@PutMapping(value="/updateFlight")
	public String updateFlight(@RequestBody Flight flight );
	
	@GetMapping(value="/viewAll")
	public List<Flight> getAllFlights();
	
	

	

		
		
		
}

