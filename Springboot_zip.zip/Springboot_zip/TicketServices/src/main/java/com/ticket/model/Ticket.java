package com.ticket.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Ticket_Info")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer ticketId;
	private Double ticketPrice;
	private Integer flightId;
	private Integer bookSeats;
	private Integer seatNumber;
	private String source;
	private String destination;
	private String dateOfJourney;
	private String pname;
	private Integer pId;
	public Integer getpId() {
		return pId;
	}
	public void setpId(Integer pId) {
		this.pId = pId;
	}
	public Integer getTicketId() {
		return ticketId;
	}
	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}
	public Double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(Double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public Integer getBookSeats() {
		return bookSeats;
	}
	public void setBookSeats(Integer bookSeats) {
		this.bookSeats = bookSeats;
	}
	public Integer getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(Integer seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(String dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
	public Ticket(Integer ticketId, Double ticketPrice, Integer flightId, Integer bookSeats, Integer seatNumber,
			String source, String destination, String dateOfJourney, String pname, Integer pId) {
		super();
		this.ticketId = ticketId;
		this.ticketPrice = ticketPrice;
		this.flightId = flightId;
		this.bookSeats = bookSeats;
		this.seatNumber = seatNumber;
		this.source = source;
		this.destination = destination;
		this.dateOfJourney = dateOfJourney;
		this.pname = pname;
		this.pId = pId;
	}
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", ticketPrice=" + ticketPrice + ", flightId=" + flightId
				+ ", bookSeats=" + bookSeats + ", seatNumber=" + seatNumber + ", source=" + source + ", destination="
				+ destination + ", dateOfJourney=" + dateOfJourney + ", pname=" + pname + ", pId=" + pId + "]";
	}
	
	
}
