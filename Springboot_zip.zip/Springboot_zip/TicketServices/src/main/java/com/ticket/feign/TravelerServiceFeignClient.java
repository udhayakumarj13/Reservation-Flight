package com.ticket.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.ticket.model.Traveler;

@FeignClient(value = "USER-SERVICE", url = "http://localhost:8000/travellers")
public interface TravelerServiceFeignClient {
	
	@GetMapping("/userLogin")
	public String getuserEmailAndPassword(@RequestParam String emailId, @RequestParam String password);

	@GetMapping(value="/getTravelerById/{pId}")
	public Traveler getTravelerById(@PathVariable Integer pId);
}
