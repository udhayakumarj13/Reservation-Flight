package com.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.model.Traveler;
import com.user.repository.TravellerRepository;
import com.user.service.TravelerService;

@RestController
@RequestMapping("travellers")
@CrossOrigin(origins = "http://localhost:4200")
public class TravellerController {
	@Autowired
	TravelerService travelservice;
	//http://localhost:8000/travellers/savetravellersdetails
	@PostMapping("/savetravellersdetails")
	public Traveler saveTravellersDetails(@RequestBody Traveler travels)
	{
		return travelservice.saveTravellersDetails(travels);
	}
	//http://localhost:8000/travellers/savetravellersdetails
	
	@GetMapping("/userLogin")
	public String getuserEmailAndPassword(@RequestParam(name="emid") String emailId, @RequestParam String password) {
	return travelservice.getUserEmailAndPassword(emailId, password);
   }
	//http://localhost:8000/travellers/gettravellerbyid/8
	@GetMapping("/gettravellerbyid/{pId}")
	public Traveler getTravelerById(@PathVariable Integer pId) {
		
		return travelservice.getTravelerById(pId);
	}
	

}
