package com.user.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Traveler_Info")
public class Traveler {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
  private Integer pId;
  private String pFirstName;
  private String pLastName;
  private String pGender;
  private String pEmailId;
  private String pCity;
  private String pCountry;
  private String pPassword;
public Integer getpId() {
	return pId;
}
public void setpId(Integer pId) {
	this.pId = pId;
}
public String getpFirstName() {
	return pFirstName;
}
public void setpFirstName(String pFirstName) {
	this.pFirstName = pFirstName;
}
public String getpLastName() {
	return pLastName;
}
public void setpLastName(String pLastName) {
	this.pLastName = pLastName;
}
public String getpGender() {
	return pGender;
}
public void setpGender(String pGender) {
	this.pGender = pGender;
}
public String getpEmailId() {
	return pEmailId;
}
public void setpEmailId(String pEmailId) {
	this.pEmailId = pEmailId;
}
public String getpCity() {
	return pCity;
}
public void setpCity(String pCity) {
	this.pCity = pCity;
}
public String getpCountry() {
	return pCountry;
}
public void setpCountry(String pCountry) {
	this.pCountry = pCountry;
}
public String getpPassword() {
	return pPassword;
}
public void setpPassword(String pPassword) {
	this.pPassword = pPassword;
}
public Traveler(Integer pId, String pFirstName, String pLastName, String pGender, String pEmailId, String pCity,
		String pCountry, String pPassword) {
	super();
	this.pId = pId;
	this.pFirstName = pFirstName;
	this.pLastName = pLastName;
	this.pGender = pGender;
	this.pEmailId = pEmailId;
	this.pCity = pCity;
	this.pCountry = pCountry;
	this.pPassword = pPassword;
}
public Traveler() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Traveler [pId=" + pId + ", pFirstName=" + pFirstName + ", pLastName=" + pLastName + ", pGender=" + pGender
			+ ", pEmailId=" + pEmailId + ", pCity=" + pCity + ", pCountry=" + pCountry + ", pPassword=" + pPassword
			+ "]";
}
  
	

}
