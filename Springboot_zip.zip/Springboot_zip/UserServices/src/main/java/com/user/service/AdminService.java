package com.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.user.model.Administrator;
import com.user.repository.AdminRepository;

@Service
public class AdminService {
	@Autowired
	AdminRepository adminrepo;
	
	public Administrator saveAdminDetails(Administrator admin)
	{
		return adminrepo.save(admin);
	}
	
	public String getAdminEmailAndPassword(@RequestParam String emailId, @RequestParam String password)
	{
		List<Administrator> adminList = adminrepo.findAll();
		for(Administrator admin: adminList)
		{
			if(admin.getEmail().equals(emailId) && admin.getPassword().equals(password))
			{
				return "Admin login successfull.....";
			}
			
			else
			{
				return "Wrong details";
			}
			
			
		}
		return null;
	}

}
