package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.model.Traveler;
import com.user.repository.TravellerRepository;

@Service
public class TravelerService {
	@Autowired
	TravellerRepository trepo;
	
	public Traveler saveTravellersDetails(Traveler travels)
	{
		return trepo.save(travels);
	}
	
	 public String getUserEmailAndPassword( String emailId, String password) { 
			Traveler traveler=trepo.findBypEmailId(emailId);
			 if(traveler.getpEmailId().equals(emailId) && traveler.getpPassword().equals(password)) {
			 return "Traveler Login Successfull..." ;
			 }
			 else {
			 return "Wrong Details" ;
			 }
			 
	}
	 
		public Traveler getTravelerById(Integer pId) {
			
			return trepo.findBypId(pId);
		}

}
