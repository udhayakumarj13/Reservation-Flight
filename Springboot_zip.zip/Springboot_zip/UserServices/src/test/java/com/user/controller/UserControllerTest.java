/**
 * 
 */
package com.user.controller;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;


import com.user.model.Administrator;
import com.user.service.AdminService;

/**
 * @author cogjava1786
 *
 */

@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.class)
public class UserControllerTest {
	
	
	@InjectMocks
	private AdminController adminController;
	
	@Mock
	private AdminService adminService;
	
	
	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testSaveAdminDetails() {
		Administrator administrator=new Administrator();
		administrator.setEmail("lavanya@gmail.com");
		administrator.setId(1);
		administrator.setName("Lavanya");
		administrator.setPassword("****");
		Mockito.when(adminService.saveAdminDetails(administrator)).thenReturn(administrator);
		Administrator adminTest=adminController.saveAdminDetails(administrator);
		assertNotNull(adminTest);
	}
	
	@Test
	public void testGetAdminEmailAndPassword() {
		Administrator administrator=new Administrator();
		administrator.setEmail("lavanya@gmail.com");
		administrator.setId(1);
		administrator.setName("Lavanya");
		administrator.setPassword("****");
		//Mockito.when(adminService.getAdminEmailAndPassword(toString(),null)).thenReturn("test");
		adminController.getAdminEmailAndPassword("lavanya@gmail.com","Lavanya");
	}
	
	
	
	
	
	

}
