package com.flight.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.flight.model.Flight;
import com.flight.service.FlightService;

@RestController
@RequestMapping("flight")
@CrossOrigin(origins = "http://localhost:4200")
public class FlightController {
	@Autowired
	FlightService flightservice;
	
	//http://localhost:9000/flight/Save
		@PostMapping(value="/Save")
		public String SaveFlight(@RequestBody Flight flight) {
			flightservice.SaveFlight(flight);
			return "Flight Saved Successfully!";
		}
		
		//http://localhost:9000/flight/SaveAlls
		@PostMapping(value="/SaveAlls")
		public String SaveFlights(@RequestBody List<Flight> flights) {
			flightservice.SaveFlights(flights);
			return "All flights saved successfully !";
		}
		
		//http://localhost:9000/flight/viewAll
		@GetMapping(value="/viewAll")
		public List<Flight> getAllFlights() {
			return (List<Flight>) flightservice.getAllFlights();
		}
		
	    //http://localhost:9000/flight/getFlightById/3
		@GetMapping(value="/getFlightById/{flightId}")
		public Flight getFlightById(@PathVariable Integer flightId) {
			return flightservice.getFlightById(flightId);
			
		}
		
		//http://localhost:9000/flight/updateFlight
		@PutMapping(value="/updateFlight")
		public String updateFlight(@RequestBody Flight flight ) {
			flightservice.updateFlight(flight);
			return " Flight is updated";
		}
		
		//http://localhost:9000/flight/deleteById?flightId=1
		@DeleteMapping(value="/deleteById/{flightId}")
		public String deleteById(@PathVariable Integer flightId) {
			flightservice.deleteById(flightId);
			return "Deleted successfully..";
			
		}
		
		
		

}
