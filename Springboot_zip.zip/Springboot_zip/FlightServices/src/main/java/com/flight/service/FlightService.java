package com.flight.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.feign.AdminFeign;
import com.flight.model.Flight;
import com.flight.repository.FlightRepository;

@Service
public class FlightService {
	@Autowired
	private FlightRepository flightrepo;
	
	@Autowired
	AdminFeign adminfeignclient;
	
	public String SaveFlight(Flight flight) {
		flightrepo.save(flight);
		return "Flight Saved Successfully!";
	}
	
	public String SaveFlights(List<Flight> flights) {
		flightrepo.saveAll(flights);
		return "All flights saved successfully !";
		}
	
	public List<Flight> getAllFlights() {
		return (List<Flight>) flightrepo.findAll();
		}
	
	public Flight getFlightById(Integer flightId) {
		return flightrepo.findByFlightId(flightId);
		} 
	
	public String updateFlight(Flight flight ) {
		Flight flightupdate=new Flight();
		flightupdate.setFlightId(flight.getFlightId());
		flightupdate.setFlightName(flight.getFlightName());
		flightupdate.setSource(flight.getSource());
		flightupdate.setDestination(flight.getDestination());
		flightupdate.setDateOfJourney(flight.getDateOfJourney());
		flightupdate.setAvailableSeats(flight.getAvailableSeats());
		flightupdate.setTicketPrice(flight.getTicketPrice());
		flightrepo.save(flightupdate);
     	return "Flight updated successfully....";
	}
	
	public void deleteById(Integer flightId) {
		flightrepo.deleteById(flightId);
	}
	


}
