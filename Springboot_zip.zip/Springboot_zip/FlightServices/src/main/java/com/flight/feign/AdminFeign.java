package com.flight.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value= "USER-SERVICE" , url= "http://localhost:8000/admin")
public interface AdminFeign {
	
	@GetMapping("/adminLogin")
	public String getAdminEmailAndPassword(@RequestParam String emailId, @RequestParam String password);
	


}
